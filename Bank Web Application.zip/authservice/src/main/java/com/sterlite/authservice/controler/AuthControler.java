package com.sterlite.authservice.controler;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.google.common.net.HttpHeaders;
import com.sterlite.authservice.entity.AuthRequest;
import com.sterlite.authservice.entity.Customer;
import com.sterlite.authservice.entity.RegisterResponse;
import com.sterlite.authservice.entity.TokenResponse;
import com.sterlite.authservice.service.AuthService;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthControler {
	
    @Autowired
    private AuthService service;

    @Autowired
    private AuthenticationManager authenticationManager;
    

    @PostMapping("/register")
    public RegisterResponse addNewUser(@RequestBody Customer user) {
        return service.saveUser(user);
    }

    @PostMapping("/token")
    public TokenResponse getToken(@RequestBody AuthRequest authRequest) {
    	try {
    		Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getCustomerID(), authRequest.getPassword()));
            if (authenticate.isAuthenticated()) {
            	TokenResponse token= new TokenResponse();
            	token.setSystemTime(LocalDateTime.now());
            	token.setToken(service.generateToken(authRequest.getCustomerID()));
                return token;
            } else {
                throw new RuntimeException("invalid access");
            }
    	}catch(Error e) {
    		 throw new RuntimeException(e);
    	}
    }

    @GetMapping("/validate")
    public String validateToken(@RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        service.validateToken(token.substring(7));
        return "Token is valid";
    }
    
    
}
