package com.sterlite.transectionservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sterlite.transectionservice.model.Transactions;

import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface TransactionDao extends JpaRepository<Transactions,Integer>{
	
	@Query(value="Select * from transactions where customer_id=?1",nativeQuery=true)
	public List<Transactions> searchTransactions(int customerId);
}
