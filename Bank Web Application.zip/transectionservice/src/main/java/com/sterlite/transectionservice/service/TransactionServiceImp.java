package com.sterlite.transectionservice.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sterlite.transectionservice.dao.TransactionDao;
import com.sterlite.transectionservice.model.Transactions;

@Service
public class TransactionServiceImp implements TransactionService{

	@Autowired
	TransactionDao dao;
	
	@Override
	public Transactions fundTransfer(Transactions a) {
		// TODO Auto-generated method stub
		a.setTimeStamp(LocalDateTime.now());
		return dao.save(a); 
	}

	@Override
	public List<Transactions> getTransactions(int customerId) {
		// TODO Auto-generated method stub
		return dao.searchTransactions(customerId); 
	}

}
