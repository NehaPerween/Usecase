package com.sterlite.transectionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransectionserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransectionserviceApplication.class, args);
	}

}
