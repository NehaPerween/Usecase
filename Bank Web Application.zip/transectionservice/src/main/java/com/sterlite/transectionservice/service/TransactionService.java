package com.sterlite.transectionservice.service;

import java.util.List;

import com.sterlite.transectionservice.model.Transactions;

public interface TransactionService {
	public Transactions fundTransfer(Transactions a); 
	
	public List<Transactions> getTransactions(int customerId);
}
