package com.sterlite.accountservice.service;
import java.util.List;

import com.sterlite.accountservice.model.ThirdPartyAccount;

public interface ThirdPartyAccountService {
	public ThirdPartyAccount addBnfAccont(ThirdPartyAccount a); 
	public List<ThirdPartyAccount> searchByCustomer(int id); 
}
