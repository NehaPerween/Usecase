package com.sterlite.accountservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.sterlite.accountservice.model.ThirdPartyAccount;

public interface ThirdPartyDao extends JpaRepository<ThirdPartyAccount,Integer>{
	
	@Query(value="Select * from third_party_accounts where customer_Id=?1",nativeQuery=true)
	public List<ThirdPartyAccount> searchByCustomerId(int userid);
}
