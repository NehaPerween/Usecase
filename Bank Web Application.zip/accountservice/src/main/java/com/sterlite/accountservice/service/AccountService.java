package com.sterlite.accountservice.service;

import java.util.Optional;

import com.sterlite.accountservice.model.Customer;


public interface AccountService {
	public Optional<Customer> getCustomer(String a);
	
	public Optional<Customer> getAccount(String a); 
	
	public Customer updateCustomerInfo(Customer a); 
}
