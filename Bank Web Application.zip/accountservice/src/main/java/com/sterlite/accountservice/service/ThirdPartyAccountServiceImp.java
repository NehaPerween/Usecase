package com.sterlite.accountservice.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sterlite.accountservice.dao.ThirdPartyDao;
import com.sterlite.accountservice.model.ThirdPartyAccount;

@Service
public class ThirdPartyAccountServiceImp implements  ThirdPartyAccountService{

	@Autowired
	ThirdPartyDao dao;
	
	@Override
	public ThirdPartyAccount addBnfAccont(ThirdPartyAccount a) {
		// TODO Auto-generated method stub
		a.setModified(LocalDateTime.now());
		return dao.save(a);
	}

	@Override
	public List<ThirdPartyAccount> searchByCustomer(int id) {
		// TODO Auto-generated method stub
		return dao.searchByCustomerId(id); 
	}
 
}
