package com.sterlite.accountservice.controler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("accounts")
@CrossOrigin(origins = "http://localhost:3000")
public class HealthCheck {
	
	@GetMapping("/health")
	public ResponseEntity<String> checkHelth(){
		return new ResponseEntity("Accounts Service Working Fine",HttpStatus.OK);
	}

}
