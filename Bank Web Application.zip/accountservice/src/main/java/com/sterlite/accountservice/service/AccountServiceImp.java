package com.sterlite.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sterlite.accountservice.dao.AccountsDao;
import com.sterlite.accountservice.model.Customer;

@Service
public class AccountServiceImp implements AccountService{
	
	@Autowired
	AccountsDao dao;

	@Override
	public Optional<Customer> getCustomer(String customerId) {
		// TODO Auto-generated method stub
		return dao.findById(Integer.parseInt(customerId)); 
	}

	@Override
	public Optional<Customer> getAccount(String a) {
		// TODO Auto-generated method stub
		List<Customer>customers=dao.searchByAccountId(Integer.parseInt(a));
		return customers.isEmpty()?null:Optional.ofNullable(customers.get(0));
	}

	@Override
	public Customer updateCustomerInfo(Customer a) {
		// TODO Auto-generated method stub
		if(dao.updateTitle(a.getCustomerId(), a.getFirstName(), a.getLastName(), a.getEmail(), a.getPhone(), a.getIfscCode())==1) {
			return a;  
		}else {
			throw new RuntimeException("Request Failed");
		}
		
	}

}
