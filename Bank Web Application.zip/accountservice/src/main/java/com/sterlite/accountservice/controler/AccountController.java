package com.sterlite.accountservice.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.sterlite.accountservice.model.Customer;
import com.sterlite.accountservice.service.AccountService;

@RestController
@RequestMapping("accounts")
@CrossOrigin(origins = "http://localhost:3000")
public class AccountController {
	
	@Autowired
	AccountService service;
	
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<Customer> getCustomer(@PathVariable(name="customerId") String id){
		return new ResponseEntity(service.getCustomer(id),HttpStatus.OK);
	}
	
	@GetMapping("/account/{accountId}")
	public ResponseEntity<Customer> getAccount(@PathVariable(name="accountId") String id){
		return new ResponseEntity(service.getAccount(id),HttpStatus.OK);
	}
	
	@PostMapping("/update")
	public ResponseEntity<Customer> updateCustomerInfo(@RequestBody Customer user){
		return new ResponseEntity(service.updateCustomerInfo(user),HttpStatus.OK);
	}
}
